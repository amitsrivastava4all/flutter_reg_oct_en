import 'dart:io';

void main() {
  // Future
  String path =
      "/Users/amitsrivastava/Documents/softwares/eclipse-java-oxygen-3a-macosx-cocoa-x86_64.dmg";
  File file = new File(path);
  if (file.existsSync()) {
    print("Before read");
    Stream stream = file.openRead();
    stream.listen((event) {
      print(event);
    });
    // Future future = file.readAsBytes();
    //future.then((value) => print(value)).catchError((err) => print(err));
  } else {
    print("File not exist");
  }
  print("After Read");
}
