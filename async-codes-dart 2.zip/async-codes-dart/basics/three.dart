void main() {
  Future<int> future = new Future(() {
    return 100;
  });
  Future<int> f2 = Future.value(100);

  Future<int> f3 = Future.delayed(Duration(seconds: 3), () => 100);
}
