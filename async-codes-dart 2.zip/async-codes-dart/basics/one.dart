void main() {
  print("Start of the Code "); // Sync
  Future<String> future = Future.delayed(
      Duration(seconds: 7), //() => "Your Pizza is Prepared...");
      () => throw new Exception("Unable to Process the Pizza"));
  print("Future is $future"); // UnCompleted Stage
  // Completion Stage with Success (Result)
  future.then((value) => print("Recieved $value")).catchError(
      (err) => print("Error is $err")); // Completion Stage but with error

  // Future.delayed(
  //     // Async (Non Blocking Code)
  //     Duration(seconds: 5),
  //     () => print("Execute After 5 Second of Time"));
  print("End of the Code ");
}
