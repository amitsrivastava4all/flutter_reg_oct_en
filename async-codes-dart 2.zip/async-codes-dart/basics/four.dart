import 'dart:async';

class NumberCountDown {
  int _counter = 0;
  StreamController<int> ctrl = StreamController<int>();
  NumberCountDown() {
    Timer.periodic(Duration(seconds: 3), (t) {
      _counter++;
      ctrl.sink.add(_counter);
      //print("Counter is $_counter");
    });
  }
  Stream<int> getStream() {
    return ctrl.stream;
  }
}

void main() {
  NumberCountDown n = new NumberCountDown();
  Stream<int> s = n.getStream();
  StreamSubscription<int> subscription = s
      .where((data) => data % 2 == 0)
      .map((data) => data * data)
      .listen((event) {
    print("Rec Data $event");
  }, onError: (err) => print("Error $err"), onDone: () => print("Stream End"));
  Timer(Duration(seconds: 10), () {
    subscription.cancel();
    print("Sub Cancel");
  });
}
