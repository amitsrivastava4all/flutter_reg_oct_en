class Song {
  String artistName;
  String trackName;
  String imageURL;
  String audioURL;
  Song(
      {required this.artistName,
      required this.trackName,
      required this.imageURL,
      required this.audioURL});
  static fromJSON(Map map) {
    return new Song(
        artistName: map['artistName'],
        trackName: map['trackName'],
        imageURL: map['artworkUrl100'],
        audioURL: map['previewUrl']);
  }

  @override
  String toString() {
    return "ArtistName ${artistName} trackName ${trackName} Image ${imageURL} AudioURL ${audioURL}";
  }
}
