import 'package:http/http.dart' as http;
import 'package:music_app_itunes/utils/config.dart';

class ApiClient {
  ApiClient._() {}
  static Future<String> getSongsByArtist(
      {String artistName = "Sonu Nigam"}) async {
    // Call Itunes API to get the songs by Artist
    var url = Uri.parse(Config.URL + artistName + "&limit=50");
    http.Response response = await http.get(url);
    return response.body;
  }
}
