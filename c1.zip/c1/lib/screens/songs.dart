import 'package:flutter/material.dart';
import 'package:music_app_itunes/models/song.dart';
import 'package:music_app_itunes/utils/api_client.dart';
import 'dart:convert' as convert;

class SongScreen extends StatefulWidget {
  const SongScreen({Key? key}) : super(key: key);

  @override
  _SongScreenState createState() => _SongScreenState();
}

class _SongScreenState extends State<SongScreen> {
  @override // i call only once and on initalize stage
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadSongs();
  }

  _loadSongs() {
    Future<String> future =
        ApiClient.getSongsByArtist(artistName: 'Sonu Nigam');
    future.then((json) {
      print("JSON Rec $json");
      print("JSON Type is ${json.runtimeType}");
      _convertJSONToObject(json);
    }).catchError((err, stacktrace) {
      print("Error is $err");
      print(stacktrace);
    });
  }

  _convertJSONToObject(String json) {
    // convert json string into map
    Map<String, dynamic> map = convert.jsonDecode(json);
    List list = map['results'];
    List<Song> songs = list
        .map((obj) => new Song(
            artistName: (obj['artistName']),
            trackName: (obj['trackName']),
            imageURL: (obj['artworkUrl100']),
            audioURL: (obj['previewUrl'])))
        .toList();
    print("List of Songs $songs");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(),
      ),
    );
  }
}
