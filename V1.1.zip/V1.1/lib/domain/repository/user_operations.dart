import 'package:firebase_auth/firebase_auth.dart';
import 'package:task_manager_app/domain/services/oauth.dart';
import '../models/user.dart' as userModel;

class UserOperations {
  Future<userModel.User> login() async {
    OAuth oAuth = new OAuth();
    UserCredential userCred = await oAuth.login(); // Login with Gmail
    User? user = userCred.user; // FireBase User
    String? name = user?.displayName;
    String? email = user?.email;
    String? photo = user?.photoURL;
    userModel.User userObject =
        userModel.User(email, name, photo); // Our Model User
    return userObject;
  }

  static loginWithFB(){
    OAuth.loginWithFB();
  }
}
