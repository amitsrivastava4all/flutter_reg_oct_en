class Config {
  Config._() {}
  static String VIDEO_URL =
      'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4';
}
