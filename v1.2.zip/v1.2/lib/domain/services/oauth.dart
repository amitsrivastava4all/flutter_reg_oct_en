import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:google_sign_in/google_sign_in.dart';

class OAuth {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = new GoogleSignIn();
  // Login with Gmail
  Future<UserCredential> login() async {
    GoogleSignInAccount? googleSignInAccount = await _googleSignIn.signIn();
    GoogleSignInAuthentication? googleSignInAuth =
        await googleSignInAccount?.authentication;
    OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuth?.accessToken,
        idToken: googleSignInAuth?.idToken);
    UserCredential userCred = await _auth.signInWithCredential(credential);
    return userCred;
  }

  static loginWithFB() async{
      FacebookLogin facebookLogin = new FacebookLogin();
      FacebookLoginResult result= await facebookLogin.logIn(['email']);
      print("####### RESULT is $result");
      switch(result.status){
        case FacebookLoginStatus.loggedIn: // Success
          FacebookAccessToken accessToken = result.accessToken;
          print(":::::::::::::: Access Token is $accessToken");
          print("Userid ${accessToken.userId}");
          print("Token ${accessToken.token}");
          break;
         case FacebookLoginStatus.cancelledByUser:
          print(":::::::::::::::: Login Cancelled ") ;
          break;
          case FacebookLoginStatus.error:
            print(":::::::::::::: Some Problem During FaceBook Login ");
            print(FacebookLoginStatus.error);
            break;
      }
  }
}
