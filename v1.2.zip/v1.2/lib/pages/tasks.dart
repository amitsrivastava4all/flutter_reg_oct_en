import 'package:flutter/material.dart';

class TaskHome extends StatefulWidget {
  const TaskHome({ Key? key }) : super(key: key);

  @override
  _TaskHomeState createState() => _TaskHomeState();
}

class _TaskHomeState extends State<TaskHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
          child: Text('Task DashBoard',style: TextStyle(fontSize: 20),),
        ),
    );
  }
}