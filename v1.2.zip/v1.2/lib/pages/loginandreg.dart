import 'package:flutter/material.dart';
import 'package:flutter_login/flutter_login.dart';
import 'package:task_manager_app/domain/repository/user_operations.dart';
import 'package:task_manager_app/pages/tasks.dart';

class LoginAndReg extends StatelessWidget {
  const LoginAndReg({ Key? key }) : super(key: key);

  Future<String?> _doLogin(LoginData data){
    // API Calls  or FireBase
    
        return UserOperations.loginWithEmailAndPassword(data.name, data.password);
        // if(data.name =='amit@yahoo.com' && data.password=='111'){
        //   return null;
        // }
        // return "Invalid Userid or Password";
    } 

    

  
  Future<String?> _doSignUp(SignupData data){
    return UserOperations.registerWithEmailAndPassword(data.name, data.password);
    // String result ;
    // return Future.delayed(Duration(seconds: 1),(){
    //   return null;
    // });
  }

  Future<String?> _recoverPwd(String userid){
    return Future.delayed(Duration(seconds: 1),(){
      return null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return FlutterLogin(
      onRecoverPassword: _recoverPwd,
      title: 'Brain Mentors',
      onLogin: _doLogin,
      onSignup: _doSignUp,
      onSubmitAnimationCompleted: (){
        Navigator.of(context).push(MaterialPageRoute(builder: (ctx)=>TaskHome()));
      },
      logo:NetworkImage('https://developers.google.com/homepage-assets/images/chromeos-logo.png')
    );
  }
}