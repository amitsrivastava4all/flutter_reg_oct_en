import 'package:flutter/material.dart';

class Grocery extends StatelessWidget {
  const Grocery({Key? key}) : super(key: key);
  Widget _searchBox() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      color: Colors.grey.shade200,
      child: TextField(
        decoration: InputDecoration(
            border: InputBorder.none,
            hintText: 'Search for Products',
            prefixIcon: Icon(Icons.search)),
      ),
    );
  }

  Widget _getBanner() {
    return Container(
      child: Image.network(
          'https://sps.honeywell.com/content/dam/honeywell-edam/sps/common/en-us/industries/retail/grocery/images/sps-grocery-hero.jpg'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        leading: Icon(Icons.menu),
        title: Text('SC -9'),
      ),
      body: Column(
        children: [_searchBox(), _getBanner()],
      ),
    );
  }
}
