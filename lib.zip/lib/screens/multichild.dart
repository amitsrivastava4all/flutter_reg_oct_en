import 'package:flutter/material.dart';

class MultiChild extends StatelessWidget {
  const MultiChild({Key? key}) : super(key: key);
  _getText(String msg, {double size = 20}) {
    return Text(
      msg,
      style: TextStyle(fontSize: size),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.ideographic,
          textDirection: TextDirection.rtl,
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _getText('Hi'),
            _getText('Hello', size: 40),
            _getText('Ok', size: 14)
            // Container(
            //   color: Colors.amber,
            //   width: 300,
            //   height: 100,
            // ),
            // Container(
            //   color: Colors.redAccent,
            //   width: 100,
            //   height: 300,
            // ),
            // Container(
            //   color: Colors.blueAccent,
            //   width: 100,
            //   height: 100,
            // )
          ],
        ),
      ),
    );
  }
}
