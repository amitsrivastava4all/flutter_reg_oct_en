import 'dart:async';

class AutoIncrementStream {
  int _counter = 0;
  StreamController<int> _streamController = StreamController<int>();
  AutoIncrementStream() {
    Timer.periodic(Duration(seconds: 3), (timer) {
      _counter++;
      _streamController.add(_counter);
    });
  }
  Stream<int> getStream() {
    return _streamController.stream;
  }
}
