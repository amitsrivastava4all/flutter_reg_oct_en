// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'song.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Song _$SongFromJson(Map<String, dynamic> json) {
  return Song(
    artistName: json['artistName'] as String,
    trackName: json['trackName'] as String,
    imageURL: json['artworkUrl100'] as String,
    audioURL: json['previewUrl'] ?? '' as String,
  );
}

Map<String, dynamic> _$SongToJson(Song instance) => <String, dynamic>{
      'artistName': instance.artistName,
      'trackName': instance.trackName,
      'artworkUrl100': instance.imageURL,
      'previewUrl': instance.audioURL,
    };
