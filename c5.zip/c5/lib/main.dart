import 'package:flutter/material.dart';
import 'package:music_app_itunes/screens/songs.dart';
import 'package:music_app_itunes/screens/streamscreen.dart';

import 'screens/futurebuilderdemo.dart';

void main() {
  runApp(MaterialApp(title: "Music App", home: FutureBuilderDemo()));
}
