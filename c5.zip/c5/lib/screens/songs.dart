import 'package:flutter/material.dart';
import 'package:music_app_itunes/models/song.dart';
import 'package:music_app_itunes/utils/api_client.dart';
import 'dart:convert' as convert;

class SongScreen extends StatefulWidget {
  const SongScreen({Key? key}) : super(key: key);

  @override
  _SongScreenState createState() => _SongScreenState();
}

class _SongScreenState extends State<SongScreen> {
  @override // i call only once and on initalize stage
  void initState() {
    // TODO: implement initState
    super.initState();
    ApiClient.addInterceptor();
    _loadSongs();
  }

  List<Widget> songWidgets = [];
  List<Song> songs = [];
  _loadSongs({String artistName = "Sonu Nigam"}) {
    Future<String> future = ApiClient.getSongsByArtist(artistName: artistName);
    future.then((json) {
      print("JSON Rec $json");
      print("JSON Type is ${json.runtimeType}");
      songs = _convertJSONToObject(json);
      setState(() {});
      // Render
      // songWidgets = songs.map((Song song) => _createSong(song)).toList();
      // setState(() {});
    }).catchError((err, stacktrace) {
      print("Error is $err");
      print(stacktrace);
    });
  }

  Widget _createSong(Song song) {
    return Container(
      margin: EdgeInsets.all(5),
      width: 150,
      height: 150,
      decoration: BoxDecoration(
          image: DecorationImage(image: NetworkImage(song.imageURL))),
    );
    // return ListTile(
    //     leading: Image.network(song.imageURL),
    //     title: Text(song.trackName),
    //     subtitle: Text(song.artistName),
    //     trailing: IconButton(
    //       icon: Icon(
    //         Icons.play_arrow_rounded,
    //       ),
    //       onPressed: () {},
    //     ));
  }

  List<Song> _convertJSONToObject(String json) {
    // convert json string into map
    Map<String, dynamic> map = convert.jsonDecode(json);
    List list = map['results'];
    List<Song> songs = list.map((songMap) => Song.fromJSON(songMap)).toList();
    // new Song(
    //     artistName: (obj['artistName']),
    //     trackName: (obj['trackName']),
    //     imageURL: (obj['artworkUrl100']),
    //     audioURL: (obj['previewUrl'] ?? ""))
    //)
    // .toList();
    print("List of Songs $songs");
    return songs;
  }

  searchIt() {
    String artistName = _tc.text;
    songWidgets = [];
    _loadSongs(artistName: artistName);
  }

  TextEditingController _tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Container(
            child: TextField(
              controller: _tc,
              decoration: InputDecoration(
                  prefixIcon: IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () {
                      searchIt();
                    },
                  ),
                  border: InputBorder.none),
            ),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(20)),
          ),
        ),
        body: SafeArea(
          // child: ListView.separated(
          //     itemBuilder: (BuildContext ctx, int index) {
          //       // return Text(songs[index].trackName);
          //       return _createSong(songs[index]);
          //     },
          //     separatorBuilder: (BuildContext ctx, int position) {
          //       return Divider(
          //         height: 2,
          //         thickness: 2.0,
          //         color: Colors.red,
          //       );
          //     },
          //     itemCount: songs.length),
          child: GridView.builder(
              padding: EdgeInsets.all(5),
              itemCount: songs.length,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
              itemBuilder: (BuildContext ctx, int index) {
                // return Text(songs[index].trackName);
                return _createSong(songs[index]);
              }),
          //     child: GridView.count(
          //   crossAxisCount: 3,
          //   children: [
          //     Text('A1'),
          //     Text('A2'),
          //     Text('A3'),
          //     Text('A4'),
          //     Text('A5'),
          //     Text('A6'),
          //     Text('A7'),
          //     Text('A8'),
          //     Text('A9'),
          //     Text('A10')
          //   ],
          // )

          // child: Container(
          //   height: 100,
          //   //width: 400,
          //   child: ListView.builder(
          //     //physics: NeverScrollableScrollPhysics(),
          //     scrollDirection: Axis.horizontal,
          //     itemBuilder: (BuildContext ctx, int index) {
          //       //return Text(songs[index].trackName);
          //       return _createSong(songs[index]);
          //     },
          //     itemCount: songs.length,
          //   ),
          // ),
          //child: ListView(
          // children: [Text('A'), Text('B'), Text('C'), Text('D'), Text('E')],
        )
        // child: SingleChildScrollView(child: Column(children: songWidgets)),
        );
  }
}
