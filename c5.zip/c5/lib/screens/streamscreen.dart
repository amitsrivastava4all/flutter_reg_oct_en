import 'package:flutter/material.dart';
import 'package:music_app_itunes/utils/streams.dart';

class StreamScreen extends StatefulWidget {
  const StreamScreen({Key? key}) : super(key: key);

  @override
  _StreamScreenState createState() => _StreamScreenState();
}

class _StreamScreenState extends State<StreamScreen> {
  @override
  Widget build(BuildContext context) {
    AutoIncrementStream _autoIncrementStream = new AutoIncrementStream();
    Stream<int> stream = _autoIncrementStream.getStream();
    return Scaffold(
      body: SafeArea(
        child: StreamBuilder<int>(
          stream: stream,
          builder: (BuildContext ctx, AsyncSnapshot<int> snapshot) {
            print(snapshot.data);
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text('No Data Yet Come');
            } //else if (snapshot.connectionState == ConnectionState.done) {
            return Center(
                child: Text(
              "Data Rec ${snapshot.data}",
              style: TextStyle(fontSize: 40),
            ));
            //}
          },
        ),
      ),
    );
  }
}
