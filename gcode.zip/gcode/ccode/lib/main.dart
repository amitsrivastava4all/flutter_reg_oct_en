import 'package:counter_app/screens/counter_app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(title: 'Counter App', home: CounterApp()));
}
