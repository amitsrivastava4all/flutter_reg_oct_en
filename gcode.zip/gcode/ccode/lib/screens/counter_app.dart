import 'package:flutter/material.dart';
// // Only for UI Thing
// class A extends StatelessWidget {
//   @override
//   Widget build(BuildContext ctx) {
//     return Text('Hi');
//   }
// }

// the CounterApp is a StateFulWidget and it create a State Instance
class CounterApp extends StatefulWidget {
  const CounterApp({Key? key}) : super(key: key);

  @override
  _CounterAppState createState() => _CounterAppState();
}

// it is using the State and Building the UI
class _CounterAppState extends State<CounterApp> {
  int _counter = 0;
  _plusIt() {
    setState(() {
      _counter++;
    });
    print("Counter is $_counter");
  }

  @override
  Widget build(BuildContext context) {
    print("Build Called.....");
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _plusIt();
        },
        child: Text(
          '+',
          style: TextStyle(fontSize: 30),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Text(
            'Counter is ${_counter}',
            style: TextStyle(fontSize: 40),
          ),
        ),
      ),
    );
  }
}
