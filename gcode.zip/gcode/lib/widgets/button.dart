import 'package:flutter/material.dart';

class MyButton extends StatelessWidget {
  String label;
  Color color;
  Function fn;
  MyButton({required this.label, this.color = Colors.red, required this.fn});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        style: ButtonStyle(backgroundColor: MaterialStateProperty.all(color)),
        onPressed: () {
          fn();
        },
        child: Text(label));
  }
}
