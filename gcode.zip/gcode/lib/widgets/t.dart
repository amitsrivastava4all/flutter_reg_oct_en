class A {
  void show() {
    print("A Show ....");
  }

  void disp() {
    print("Disp");
  }
}
