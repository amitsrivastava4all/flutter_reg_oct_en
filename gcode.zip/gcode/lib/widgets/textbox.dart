import 'package:flutter/material.dart';

class TextBox extends StatelessWidget {
  String label;
  TextEditingController ctrl;
  //Function fn;
  //TextBox(this.label, this.fn);
  TextBox(this.label, this.ctrl);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        // onChanged: (String str) {
        //   //print("Str ::: $str");
        //   fn(str); // CallBack Fn
        // },
        decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            hintText: 'Type ${label} Name Here',
            prefixIcon: Icon(Icons.person)),
      ),
    );
  }
}
