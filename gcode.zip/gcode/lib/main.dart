import 'package:flutter/material.dart';
import 'package:greet_app/screens/greet.dart';

void main() {
  runApp(MaterialApp(
    home: GreetApp(),
    title: 'Greet App',
  ));
}
