import 'package:flutter/material.dart';
import 'package:greet_app/widgets/button.dart';
import '../widgets/textbox.dart';

class GreetApp extends StatefulWidget {
  const GreetApp({Key? key}) : super(key: key);

  @override
  _GreetAppState createState() => _GreetAppState();
}

class _GreetAppState extends State<GreetApp> {
  String firstName = "";
  String lastName = "";

  String _message = "";
  setFirstName(String value) {
    firstName = value;
  }

  setLastName(String value) {
    lastName = value;
  }

  showFullName() {
    firstName = tc1.text;
    lastName = tc2.text;
    _message = "Welcome ${firstName} ${lastName}";
    setState(() {});
  }

  clearAll() {
    tc1.text = "";
    tc2.text = "";
    _message = "";
    setState(() {});
  }

  TextEditingController tc1 = TextEditingController();
  TextEditingController tc2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.all(10),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Greet App',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.red,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    Expanded(child: Text('FirstName')),
                    Expanded(
                      // child: TextBox('First', setFirstName),
                      child: TextBox('First', tc1),
                      flex: 2,
                    )
                  ],
                ),
                Row(
                  children: [
                    Expanded(child: Text('LastName')),
                    Expanded(
                      //child: TextBox('Last', setLastName),
                      child: TextBox('Last', tc2),
                      flex: 2,
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    MyButton(
                      fn: showFullName,
                      label: 'Greet',
                      color: Colors.green,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    MyButton(
                      fn: clearAll,
                      label: 'Clear All',
                    )
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  _message,
                  style: TextStyle(fontSize: 30),
                )
                // Row(
                //   children: [Text('LastName'), TextField()],
                // )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
