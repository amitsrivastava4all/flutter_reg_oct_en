import 'package:flutter/material.dart';
import 'package:ted_app_eg/widgets/ted_appbar.dart';
import 'package:ted_app_eg/widgets/ted_section.dart';

class Ted extends StatelessWidget {
  const Ted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.red,
        onPressed: () {},
        child: Icon(Icons.search),
      ),
      appBar: PreferredSize(
          child: TedAppbar(), preferredSize: Size(double.infinity, 50)),
      body: SingleChildScrollView(child: TedSection()),
    );
  }
}
