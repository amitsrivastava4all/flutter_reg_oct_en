import 'package:flutter/material.dart';
import 'package:ted_app_eg/screens/ted.dart';

void main() {
  runApp(MaterialApp(
    title: 'Ted App',
    home: Ted(),
    debugShowCheckedModeBanner: false,
  ));
}
