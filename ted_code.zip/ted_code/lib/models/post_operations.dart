import 'post.dart';

class PostOperations {
  PostOperations._() {}
  static List<Post> fillPost() {
    return [
      Post(
          URL:
              'https://s3.amazonaws.com/talkstar-photos/uploads/0a95ffba-8cfe-4d9c-8913-736275f78bf9/MatthewWalker_2019-embed.jpg',
          title: 'Ted',
          subTitle: 'Conf',
          time: '10:10'),
      Post(
          URL:
              'https://s3.amazonaws.com/talkstar-photos/uploads/7adc2250-de27-4116-b4ea-6fb4637ca98a/LeraBoroditsky_2017W-embed.jpg',
          title: 'Ted2',
          subTitle: 'Conf2',
          time: '12:10'),
      Post(
          URL:
              'https://www.techwalls.com/wp-content/uploads/2013/03/ted-conference.jpg',
          title: 'TED3',
          subTitle: 'CONF3',
          time: '1:10'),
      Post(
          URL:
              'https://www.incimages.com/uploaded_files/image/1920x1080/getty_674577882_259941.jpg',
          title: 'TED4',
          subTitle: 'CONF4',
          time: '2:10'),
      Post(
          URL:
              'https://talkstar-assets.s3.amazonaws.com/production/playlists/playlist_125/03319a10-ba41-4f78-9d21-0c0233c59658/TED-Talks-Education_1200x627.jpg',
          title: 'Edu',
          subTitle: 'Edu Conf',
          time: '4:10'),
      Post(
          URL:
              'https://pi.tedcdn.com/r/talkstar-photos.s3.amazonaws.com/uploads/02e57cc0-3778-4a9c-8bdd-6497e026ecb9/EktaKapoor_2017I-embed.jpg',
          title: 'Ekta Kapoor',
          subTitle: 'Conf6',
          time: '5:10')
    ];
  }
}
