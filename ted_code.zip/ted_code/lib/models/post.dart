class Post {
  String URL;
  String title;
  String subTitle;
  String time;
  Post(
      {required this.URL,
      required this.title,
      required this.subTitle,
      required this.time});
}
