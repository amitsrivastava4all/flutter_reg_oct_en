import 'package:flutter/material.dart';
import 'package:ted_app_eg/models/post.dart';
import 'package:ted_app_eg/models/post_operations.dart';
import 'package:ted_app_eg/widgets/ted_card.dart';

class TedSection extends StatelessWidget {
  const TedSection({Key? key}) : super(key: key);

  List<Widget> _prepareCards() {
    List<Post> posts = PostOperations.fillPost();
    List<Widget> postWidgets = posts.map((post) => TedCard(post)).toList();
    return postWidgets;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: _prepareCards(),
      ),
    );
  }
}
