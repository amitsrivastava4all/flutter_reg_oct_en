import 'package:flutter/material.dart';

class TedAppbar extends StatelessWidget {
  const TedAppbar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      actions: [
        Icon(
          Icons.more_vert,
          color: Colors.grey,
        ),
        SizedBox(
          width: 20,
        )
      ],
      title: Padding(
        padding: EdgeInsets.only(left: 10),
        child: Row(
          children: [
            Text(
              'TED ',
              style: TextStyle(
                  fontFamily: 'amit',
                  color: Colors.red,
                  fontWeight: FontWeight.bold),
            ),
            Text('Talks', style: TextStyle(color: Colors.red)),
          ],
        ),
      ),
    );
  }
}
