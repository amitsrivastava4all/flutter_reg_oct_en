import 'package:flutter/material.dart';
import 'package:ted_app_eg/models/post.dart';

class TedCard extends StatelessWidget {
  Post post;
  TedCard(this.post);

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Container(
      child: Card(
        elevation: 10,
        child: Stack(
          children: [
            Image.network(post.URL),
            Positioned(
              bottom: 10,
              left: 10,
              width: deviceSize.width - 20,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          post.title,
                          style: TextStyle(color: Colors.white),
                        ),
                        Icon(Icons.more_vert, color: Colors.white)
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(post.subTitle,
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                        ElevatedButton(onPressed: () {}, child: Text('OK'))
                        // Text(post.time, style: TextStyle(color: Colors.white))
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
