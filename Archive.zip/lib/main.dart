import 'package:flutter/material.dart';

import 'screens/home.dart';

void main() {
  // Entry point of Dart Program
  runApp(MaterialApp(
      title: 'My First App',
      debugShowCheckedModeBanner: false,
      //theme: ThemeData.light(),
      theme: ThemeData(
          scaffoldBackgroundColor: Colors.greenAccent,
          appBarTheme: AppBarTheme(color: Colors.deepOrange)),
      home: Home()
      // home: Container(
      //   color: Colors.orange,
      //   child: Text('Hello flutter'),
      // )
      // home: SafeArea(child: Text('Hi Flutter')),
      ));
}
