import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  // build - build a User Interface
  @override
  Widget build(BuildContext context) {
    const URL =
        'https://www.denofgeek.com/wp-content/uploads/2019/02/mcu-1-iron-man.jpg';
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter-App'),
      ),
      body: Container(
        child: Image.asset('assets/images/im.jpg'),
        // child: Image.network(
        //   URL,
        //   fit: BoxFit.contain,
        //   // width: 1500,
        //   // height: 1700,
        // ),
        // child: Center(
        //   child: Text(
        //     'Hello-Flutter',
        //     style: TextStyle(fontSize: 50),
        //   ),
        // ),
        color: Colors.amber,
      ),
    );
  }
}
