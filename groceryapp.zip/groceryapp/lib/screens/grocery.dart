import '/models/product.dart';
import '/models/product_operations.dart';
import 'package:flutter/material.dart';

class Grocery extends StatelessWidget {
  const Grocery({Key? key}) : super(key: key);
  Widget _searchBox() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      color: Colors.grey.shade200,
      child: TextField(
        decoration: InputDecoration(
            border: InputBorder.none,
            hintText: 'Search for Products',
            prefixIcon: Icon(Icons.search)),
      ),
    );
  }

  Widget _getBanner() {
    return Container(
      child: Image.network(
          'https://sps.honeywell.com/content/dam/honeywell-edam/sps/common/en-us/industries/retail/grocery/images/sps-grocery-hero.jpg'),
    );
  }

//  Widget _rowOfProducts(){
//     return Row(children: [
//       _getProduct(product)
//     ],)
//   }
  Widget _getProduct(Product product) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.all(10),
          padding: EdgeInsets.all(10),
          color: Colors.grey.shade200,
          width: 100,
          height: 100,
          child: Image.network(product.URL),
        ),
        Text(
          product.name,
          style: TextStyle(fontWeight: FontWeight.bold),
        )
      ],
    );
  }

  Widget _allProducts() {
    List<Product> products = ProductOperations.fill();
    // products.map((Product product) {
    //   Widget productWidget = _getProduct(product);
    //   return productWidget;
    // });
    // Map is Traverse your list internally and then create list of widgets
    // Map is act as a Bridge b/w the data and the widget
    List<Widget> productWidgets =
        products.map((Product product) => _getProduct(product)).toList();

    // Traverse the Product Widgets
    List<Widget> threeChild = [];
    List<Row> rows = [];
    int count = 0;
    for (int i = 0; i < productWidgets.length; i++) {
      threeChild.add(productWidgets[i]);
      count++;
      if (count % 3 == 0) {
        rows.add(Row(
          children: threeChild,
        ));
        threeChild = []; // Empty the Previous Row Childs
      }
    }
    if (threeChild.length > 0) {
      rows.add(Row(
        children: threeChild,
      ));
    }
    return Container(
      margin: EdgeInsets.only(left: 30, top: 10),
      child: Column(
        children: rows,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(),
      appBar: AppBar(
        backgroundColor: Colors.orange,
        // leading: Icon(Icons.menu),
        title: Text('SC -9'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _searchBox(),
            Divider(
              color: Colors.grey,
              height: 1,
            ),
            SizedBox(
              height: 5,
            ),
            _getBanner(),
            _allProducts()
          ],
        ),
      ),
    );
  }
}
