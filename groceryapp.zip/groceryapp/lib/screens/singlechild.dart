import 'package:flutter/material.dart';

class SingleChild extends StatelessWidget {
  const SingleChild({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.only(left: 10, top: 10),
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: NetworkImage(
                      'https://mystickermania.com/cdn/stickers/deadpool/sticker_2052-512x512.png')),
              boxShadow: [
                BoxShadow(blurRadius: 30, color: Colors.deepOrange),
                BoxShadow(blurRadius: 30, color: Colors.black)
              ],
              shape: BoxShape.circle,
              gradient: SweepGradient(
                  //RadialGradient(
                  colors: [
                    Colors.orange,
                    Colors.blueAccent,
                    Colors.purpleAccent,
                    Colors.greenAccent
                  ], stops: [
                0.0,
                0.25,
                0.50,
                1.0
              ]
                  //begin: Alignment.topLeft, end: Alignment.bottomRight
                  ),
              //borderRadius: BorderRadius.circular(50),
              color: Colors.amberAccent,
              border: Border.all(color: Colors.red, width: 4)),
          //padding: EdgeInsets.all(50),
          padding: EdgeInsets.only(left: 100, top: 200),
          child: Text(
            'Hello Flutter',
            style: TextStyle(fontSize: 20),
          ),
          width: 350,
          height: 600,
          //color: Colors.amber,
        ),
        // child: Center(
        //   child: Text('Hello Flutter'),
        // ),
      ),
    );
  }
}
