import 'package:flutter/material.dart';

class CardDemo extends StatelessWidget {
  const CardDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const URL1 = "https://wallpapercave.com/wp/GLUviaz.jpg";
    const URL3 = "https://wallpaperaccess.com/full/526.jpg";
    return Scaffold(
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.all(15),
          child: Column(
            children: [
              Card(
                shadowColor: Colors.blue,
                elevation: 10,
                child: Image.network(URL1),
              ),
              Card(
                shadowColor: Colors.red,
                elevation: 5,
                child: Image.network(URL3),
              )
            ],
          ),
        ),
      ),
    );
  }
}
