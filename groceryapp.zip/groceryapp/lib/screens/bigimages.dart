import 'package:flutter/material.dart';

class BigImages extends StatelessWidget {
  const BigImages({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const URL1 = "https://wallpapercave.com/wp/GLUviaz.jpg";
    const URL2 =
        "https://www.kolpaper.com/wp-content/uploads/2020/03/spiderman-wallpaper.jpg";
    const URL3 = "https://wallpaperaccess.com/full/526.jpg";
    return Scaffold(
      body: SafeArea(
        child: Row(
          //mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              child: Image.network(URL1),
              flex: 2,
            ),
            Expanded(
              child: Image.network(
                URL2,
              ),
              flex: 1,
            ),
            Expanded(
              child: Image.network(URL3),
              flex: 3,
            )
          ],
        ),
      ),
    );
  }
}
