import 'package:flutter/material.dart';

class StackDemo extends StatelessWidget {
  const StackDemo({Key? key}) : super(key: key);
  Widget _getContainer(double width, double height, Color color) {
    return Container(
      color: color,
      width: width,
      height: height,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Positioned(
                // width: 300,
                // height: 300,
                // left: 10,
                // top: 20,
                child: Container(color: Colors.red)),
            Positioned(
                width: 200,
                height: 200,
                left: 60,
                top: 200,
                child: _getContainer(200, 200, Colors.green)),
            Positioned(
                width: 100,
                height: 100,
                left: 90,
                top: 300,
                child: _getContainer(100, 100, Colors.blue))
          ],
        ),
      ),
    );
  }
}
