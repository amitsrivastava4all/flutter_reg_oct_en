import 'package:firstapp/screens/bigimages.dart';
import 'package:firstapp/screens/carddemp.dart';
import 'package:firstapp/screens/grocery.dart';
import 'package:firstapp/screens/multichild.dart';
import 'package:firstapp/screens/stackdemo.dart';
import 'package:flutter/material.dart';

import 'screens/home.dart';
import 'screens/singlechild.dart';

void main() {
  // Entry point of Dart Program
  runApp(MaterialApp(
    title: 'My First App',
    debugShowCheckedModeBanner: false,
    //theme: ThemeData.light(),
    theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(color: Colors.deepOrange)),
    //home: MultiChild()
    // home: Grocery()
    // home: BigImages()
    //home: StackDemo(),
    home: CardDemo(),
    // home: Container(
    //   color: Colors.orange,
    //   child: Text('Hello flutter'),
    // )
    // home: SafeArea(child: Text('Hi Flutter')),
  ));
}
