class Product {
  String name;
  String URL;
  Product(this.name, this.URL);
}
