// CRUD Operations
import 'package:firstapp/models/product.dart';

class ProductOperations {
  ProductOperations._() {}
  static List<Product> fill() {
    // Assume the DATA is HardCoded
    return [
      Product('Oil',
          'https://www.bigbasket.com/media/uploads/p/xxl/40059441_2-engine-kacchi-ghani-mustard-oil.jpg'),
      Product('Soap',
          'https://www.bigbasket.com/media/uploads/p/xxl/40114547_5-khadi-natural-rose-water-soap.jpg'),
      Product('Fruit',
          'https://cdn.pixabay.com/photo/2020/04/07/06/07/apple-5012196_1280.png'),
      Product('Veg',
          'https://sciencebob.com/wp-content/uploads/2015/04/tomato_small.png'),
      Product('Non Veg',
          'https://purepng.com/public/uploads/large/91508177304fwtqbi6ctvq3s7govin9kdhbopkgx6pm2tw9buwrhpiqjgygotyhs5dblx1tu7hnlc4ybfyrbkoebudhrtkjjfco08gx1ebrpncy.png'),
      Product('Soup',
          'https://nearshop.in/wp-content/uploads/2020/11/1600083397983_1600083349253-14.png'),
      Product('Green Veg',
          'https://aderonkebamidele.com/wp-content/uploads/2017/10/main-qimg-94e4e52fe36af717ea3c4923b3ed8f76.gif'),
      Product('Oil',
          'https://www.bigbasket.com/media/uploads/p/xxl/40059441_2-engine-kacchi-ghani-mustard-oil.jpg'),
      Product('Soap',
          'https://www.bigbasket.com/media/uploads/p/xxl/40114547_5-khadi-natural-rose-water-soap.jpg'),
      Product('Fruit',
          'https://cdn.pixabay.com/photo/2020/04/07/06/07/apple-5012196_1280.png'),
      Product('Veg',
          'https://sciencebob.com/wp-content/uploads/2015/04/tomato_small.png'),
      Product('Non Veg',
          'https://purepng.com/public/uploads/large/91508177304fwtqbi6ctvq3s7govin9kdhbopkgx6pm2tw9buwrhpiqjgygotyhs5dblx1tu7hnlc4ybfyrbkoebudhrtkjjfco08gx1ebrpncy.png'),
      Product('Soup',
          'https://nearshop.in/wp-content/uploads/2020/11/1600083397983_1600083349253-14.png'),
      Product('Green Veg',
          'https://aderonkebamidele.com/wp-content/uploads/2017/10/main-qimg-94e4e52fe36af717ea3c4923b3ed8f76.gif'),
      Product('Oil',
          'https://www.bigbasket.com/media/uploads/p/xxl/40059441_2-engine-kacchi-ghani-mustard-oil.jpg'),
      Product('ToothPaste',
          'https://www.colgate.com/content/dam/cp-sites/oral-care/oral-care-center-relaunch/en-us/products/toothpaste/colgate-total-whitening-toothpaste-2021.png'),
    ];
  }
}
