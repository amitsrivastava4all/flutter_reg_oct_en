class Config {
  Config._() {}
  static final String URL = "https://itunes.apple.com/search?term=";
}
