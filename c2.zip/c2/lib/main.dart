import 'package:flutter/material.dart';
import 'package:music_app_itunes/screens/songs.dart';

void main() {
  runApp(MaterialApp(
    title: "Music App",
    home: SongScreen(),
  ));
}
