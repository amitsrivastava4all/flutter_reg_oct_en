class User {
  late String name; // Lazy , Object is created
  late String pwd;
  static int counter = 0; // Eagerly / Class is Loaded
  User(String name, String pwd) {
    this.name = name;
    this.pwd = pwd;
    counter++;
    // User.counter++;
    print("Counter is " + counter.toString());
  }
}

class MathOpr {
  MathOpr._init() {}
  static sin() {}
}

void main() {
  //MathOpr opr = new MathOpr();
  MathOpr.sin();
  User user1 = new User("amit", "1111");
  User user2 = new User("ram", "1111");
  User user3 = new User("shyam", "1111");
  User user4 = new User("tim", "1111");
}
