class Player {
  // what to do
  void kick() {}
  void punch() {}
  void walk() {}
  void run() {}
  void jump() {}
}

class StarPlayer {
  void hide() {}
  void show() {}
}

// How to do
class Ken implements Player, StarPlayer {
  @override
  void jump() {
    print("Jump Average");
  }

  @override
  void kick() {
    print("Poor Kicks");
    // TODO: implement kick
  }

  @override
  void punch() {
    print("Excellent Punch");
    // TODO: implement punch
  }

  @override
  void run() {
    print("Average Walk");
    // TODO: implement run
  }

  @override
  void walk() {
    // TODO: implement walk
  }

  @override
  void hide() {
    // TODO: implement hide
  }

  @override
  void show() {
    // TODO: implement show
  }
}

// How to do
class Ryu implements Player {
  @override
  void jump() {
    print("Good Jump");
    // TODO: implement jump
  }

  @override
  void kick() {
    print("Excellent Kick");
    // TODO: implement kick
  }

  @override
  void punch() {
    print("Poor Punch");
    // TODO: implement punch
  }

  @override
  void run() {
    print("Average Walk");
    // TODO: implement run
  }

  @override
  void walk() {
    // TODO: implement walk
  }
}

void main() {
  Ken ken = new Ken();
  ken.jump();
  ken.punch();

  Ryu ryu = new Ryu();
  ryu.jump();
  ryu.punch();
  ryu.kick();
}
