abstract class Account {
  int id;
  String name;
  double balance;
  Account(this.id, this.name, this.balance);
  void computeROI(); // define as abstract method.
  void printDetails() {
    print("Id $id Name $name Balance $balance");
  }
}

class CurrentAccount extends Account {
  CurrentAccount(int id, String name, double balance)
      : super(id, name, balance);

  @override
  void computeROI() {
    print("PAY ROI 5%");
    // TODO: implement computeROI
  }
}

class FixedDepositAccount extends Account {
  FixedDepositAccount(int id, String name, double balance)
      : super(id, name, balance);

  @override
  void computeROI() {
    print("PAY ROI 7%");
    // TODO: implement computeROI
  }
}

// Constructor Chaining
class SavingAccount extends Account {
  String nomName;
  String services;
  SavingAccount(
      this.nomName, this.services, String name, int id, double balance)
      : super(id, name, balance);

  @override
  void printDetails() {
    super.printDetails();
    print(" NomName $nomName Services $services");
  }

  @override
  void computeROI() {
    print("REC ROI 4%");
    // TODO: implement computeROI
  }
}

void main() {
  //Account account = new Account(1002, "Amit", 10000);
  CurrentAccount ca = new CurrentAccount(1002, "Amit", 10000);
  ca.printDetails();
  SavingAccount sa =
      new SavingAccount("X", "Door to Door Service", "Amit", 1001, 9999);
  sa.printDetails();
}
