import 'student.dart';

void main() {
  int x = 10;
  //Student amit = new Student.takeIdAndName(1001, "Amit");
  Student amit = Student.takeOptional(id: 1001);
  //Student amit = Student(1001, "Amit", [90, 80, 70]);
  //amit._id = -1001;
  // amit._name = "Amit";
  // amit._marks = [-90, 80, -70];
  //amit.takeInput(1001, "Amit", [90, 80, 70]);
  amit.printDetails();

  //Student ram = new Student(1002, "Ram", [66, 80, 70]);
  Student ram = new Student.takeAll(1002, "Ram", [66, 80, 70]);
  ram.printDetails();
  // amit.id = -1001;
  // amit.name = "Amit";
  // amit.marks = [-90, -80, -70];
  // print(amit.id);
  // print(amit.name);
  // print(amit.marks);
}
