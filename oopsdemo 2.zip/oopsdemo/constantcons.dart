class A {
  final int x;
  final int y;
  const A(this.x, this.y); // Cons ShortHand
}

void main() {
  A a = new A(100, 200);
  A a2 = new A(101, 201);
  // a.x++;
  // a.y--;
  print(a.x);
  print(a.y);
}
