// single inheritance
class X {}

class Y extends X {}

class Z extends X {}

class GrandFather {}

class Father extends GrandFather {}

class Son extends Father {}
// Multi Level Inheritance

// Multiple Inheritance - so for classes not supported but for interfaces it supported