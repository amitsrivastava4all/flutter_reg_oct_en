class Student {
  // Members (Instance Members)
  late int _id;
  late String _name;
  late List<int> _marks;
  Student() {
    // print("1. I am the Default constructor and i call when object is created");
    _id = 0;
    _name = "";
    _marks = [];
  }
  // Param Constructor call
  // Student(int id, String name, List<int> marks) {
  //   _id = id;
  //   _name = name;
  //   _marks = marks;
  // }
  // Constructor ShortHand
  //Student(this._id, this._name, this._marks);
  Student.takeOptional(
      {int id = 0, String name = "", List<int> marks = const []}) {
    _id = id;
    _name = name;
    _marks = marks;
  }
  Student.takeAll(this._id, this._name, this._marks);
  Student.takeNameAndMarks(String name, List<int> marks)
      : this.takeAll(0, name, marks); // Redirecting a Constructor

  Student.takeIdAndName(int id, String name) : this.takeAll(id, name, []);
  //{
  //   _name = name;
  //   _id = id;
  // }

  void takeInput(int id, String name, List<int> marks) {
    print("2. Take input call");
    if (id <= 0) {
      print("Invalid Id Not Allowed");
      return; // exit from a function
    }
    for (int mark in marks) {
      if (mark < 0) {
        print("Invalid Marks");
        return;
      }
    }
    // this is a keyword , it hold the current calling object reference
    // this.id (amit.id)  = id (Local var)
    _id = id;
    this._name = name;
    this._marks = marks;
  }

  void printDetails() {
    print("Id $_id Name $_name Marks $_marks");
  }
}
