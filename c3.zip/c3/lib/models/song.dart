import 'package:json_annotation/json_annotation.dart';
part 'song.g.dart';

@JsonSerializable()
class Song {
  @JsonKey(name: 'artistName')
  String artistName;
  @JsonKey(name: 'trackName')
  String trackName;
  @JsonKey(name: 'artworkUrl100')
  String imageURL;
  @JsonKey(name: 'previewUrl')
  String audioURL;
  Song(
      {required this.artistName,
      required this.trackName,
      required this.imageURL,
      required this.audioURL});
  static Song fromJSON(Map<String, dynamic> map) {
    return _$SongFromJson(map);
  }

  Map<String, dynamic> toJSON() {
    return _$SongToJson(this);
  }
  // Map(JSON) to Object (DeSerialization)
  // static fromJSON(Map<String, dynamic> map) {
  //   return new Song(
  //       artistName: map['artistName'],
  //       trackName: map['trackName'],
  //       imageURL: map['artworkUrl100'],
  //       audioURL: map['previewUrl']);
  // }

  // Object to JSON  (Serializtion)
  // Map<String, dynamic> toJSON() {
  //   return {
  //     "artistName": artistName,
  //     "trackName": trackName,
  //     "previewUrl": audioURL,
  //     "artworkUrl100": imageURL
  //   };
  // }

  @override
  String toString() {
    return "ArtistName ${artistName} trackName ${trackName} Image ${imageURL} AudioURL ${audioURL}";
  }
}
