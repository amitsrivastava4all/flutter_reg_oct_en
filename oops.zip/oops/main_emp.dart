import 'emp.dart';

void main() {
  int x = 100;
  Employee amit = Employee();
  amit.takeInput(-1001, "Amit");
  amit.printEmp();
  // amit._id = -1001;
  // amit._name = "Amit";
  // print(amit.id);
  // print(amit.name);
}
