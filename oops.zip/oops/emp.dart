class Employee {
  late int _id;
  late String _name;
  void takeInput(int id, String name) {
    if (id <= 0 || name.length <= 2) {
      print("Wrong Input Not Allowed...");
      // _id = 0;
      // _name = "";
      return; // exit from a function
    }
    _id = id;
    _name = name;
  }

  void printEmp() {
    _id = 0;
    _name = '';
    print("Id ${_id} Name ${_name}");
  }
}
