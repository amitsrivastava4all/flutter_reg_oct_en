import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_crud/models/user.dart';

class DB {
  static FirebaseFirestore dbRef = FirebaseFirestore.instance;
  static Future<String> addRecord(User user) async {
    CollectionReference userCollection = dbRef.collection('users');
    DocumentReference doc = await userCollection.add(user.toJSON());
    return doc.id;
  }

  updateRecord() {
    dbRef.collection('users').doc('1').update({'name': 'Tim'});
  }

  deleteRecord() {
    dbRef.collection('users').doc('1').delete();
  }

  filterARecord() async {
    QuerySnapshot querySnapshot = await dbRef.collection('users').get();
    return querySnapshot.docs.where((doc) => doc['name'] == 'Amit').toList();
  }

  static Future<List<User>> getAllRecords() async {
    List<User> users = [];
    QuerySnapshot querySnapshot = await dbRef.collection('users').get();
    querySnapshot.docs.forEach((QueryDocumentSnapshot doc) {
      String name = doc['name'];
      String city = doc['city'];
      User user = new User(name, city);
      users.add(user);
    });
    print("Users are $users");
    return users;
  }
}
