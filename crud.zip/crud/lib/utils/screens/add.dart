import 'package:firebase_crud/models/user.dart';
import 'package:firebase_crud/utils/screens/view.dart';
import 'package:flutter/material.dart';

import '../db.dart';

class Add extends StatefulWidget {
  const Add({Key? key}) : super(key: key);

  @override
  _AddState createState() => _AddState();
}

class _AddState extends State<Add> {
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  String msg = "";
  _viewRecords() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (BuildContext ctx) => ViewAll()));
  }

  _addInDB() async {
    String name = t1.text;
    String city = t2.text;
    User user = new User(name, city);
    try {
      String id = await DB.addRecord(user);
      msg = "Record Added $id";
    } catch (err) {
      msg = "Error in Record Addition";
      print(err);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Text(
              msg,
              style: TextStyle(fontSize: 30),
            ),
            TextField(
              controller: t1,
              decoration: InputDecoration(hintText: 'Type Ur Name here'),
            ),
            TextField(
                controller: t2,
                decoration: InputDecoration(hintText: 'Type Ur Address here')),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              ElevatedButton(
                  onPressed: () {
                    _addInDB();
                  },
                  child: Text('Add')),
              SizedBox(
                width: 10,
              ),
              ElevatedButton(
                  onPressed: () {
                    _viewRecords();
                  },
                  child: Text('View All'))
            ])
          ],
        ),
      ),
    );
  }
}
