class User {
  String name;
  String city;
  User(this.name, this.city);
  toJSON() {
    return {"name": name, "city": city};
  }

  @override
  String toString() {
    return "Name $name City $city";
  }
}
