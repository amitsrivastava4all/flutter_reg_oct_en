import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_eg/models/counter_provider.dart';
import 'package:provider_eg/screens/counter_screen.dart';

void main(){
  runApp(MaterialApp(
    home: ChangeNotifierProvider<CounterProvider>(
      create: (_)=>CounterProvider(),
      child: CounterScreen()),
  ));
}