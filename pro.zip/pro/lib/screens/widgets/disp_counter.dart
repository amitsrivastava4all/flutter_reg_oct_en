import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_eg/models/counter_provider.dart';

class DisplayCounter extends StatelessWidget {
  const DisplayCounter({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CounterProvider obj = Provider.of<CounterProvider>(context);
    
    return Container(
        child: Text('Counter is '+obj.getCount().toString(),style: TextStyle(fontSize: 30),),
    );
  }
}