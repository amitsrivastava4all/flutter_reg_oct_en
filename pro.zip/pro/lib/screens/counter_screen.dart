
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider_eg/models/counter_provider.dart';
import 'package:provider_eg/screens/widgets/disp_counter.dart';

class CounterScreen extends StatelessWidget {
  

  late BuildContext ctx;
  plusIt(){
    CounterProvider obj = Provider.of<CounterProvider>(ctx,listen: false);
    obj.plus();
  }

  minusIt(){
CounterProvider obj = Provider.of<CounterProvider>(ctx, listen:false);
    obj.minus();
  }
  @override
  Widget build(BuildContext context) {
    ctx = context;
    return Scaffold(
        body: SafeArea(child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              Container( 
                margin: EdgeInsets.all(20),
                child: ElevatedButton(onPressed: (){
                  plusIt();
                },child: Text('+', style: TextStyle(fontSize: 30),),),),
               Container(child: ElevatedButton(onPressed: (){
                 minusIt();
               },child: Text('-', style: TextStyle(fontSize: 30),),),),
            ],),
            
           
            DisplayCounter()
          
          ],),
        )),
    );
  }
}