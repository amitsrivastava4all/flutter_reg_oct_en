import 'package:flutter/material.dart';

class CounterProvider with ChangeNotifier{
  int _count = 0;

  int getCount(){
    return _count;
  }

  void plus(){
    _count++;
    print("Plus $_count");
    notifyListeners();
  }

  void minus(){
    _count--;
    notifyListeners();
  }

}